
The provided archive contains binaries necessary to run CUDA solutions from 
FORTRAN.
The archive is intended to be used with 64 bit systems and CUDA compliant 
version (the API supported is CUDA 2.0).

Contents:
    * cuda.o - Contains bindings to CUDA 2.0 driver API
    * cufft.o - Contains bindings to CUFFT API

    * test.f - A sample application that demonstartes how it is possible
               to use CUDA management API from FORTRAN.
    * test2.f - A sample application that shows how to execute a CUDA module 
                from FORTRAN.
    * test2.cu - The CUDA file containing the kernel function being executed
                 by test2.f.

------------------------
Compilation instructions
------------------------
Please note that in the following examples the FORTRAN compiler being used is
gfortran. Any other FORTRAN compiler that is compliant with GNU can be used, 
such as f95, g77 or ifort by Intel.

test.f:
  To compile test.f issue the following command:
  gfortran test.f cuda.o -lcuda -o test

  The resulting 'test' file, is an executable that can be run.

test2.f:
  Before compiling the FORTRAN file, it is necessary to first create the cubin 
  module:
  nvcc test2.cu --cubin

  Once, we have a file named test2.cubin, we should replace the path string 
  that appears in the FORTRAN code, to the one that matches the new cubin file
  path.
  After that, simply issue:
  gfortran test2.f cuda.o -lcuda -o test2

  The resulting test2 file is an executable that can be run.

Copyright 2008 Company for Advanced Supercomputing Solutions Ltd (GASS).
All rights reserved.

For questions or further information: fortran@gass-ltd.co.il
Shoham, Israel
http://www.gass-ltd.co.il

